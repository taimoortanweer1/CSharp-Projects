﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfApplication2
{
   public class ListViewItemsData
    {
        public string GridViewColumnName_ImageSource { get; set; }
        public string GridViewColumnName_LabelContent { get; set; }
        public string GridViewColumnName_ID { get; set; }
        public string GridViewColumnTags { get; set; }
        public string GridViewColumnLocation { get; set; }
    }//end of class...
}
